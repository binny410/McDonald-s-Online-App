package com.example.welcome.mcdonalds;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Book extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);
    }
    public void orderFood(View view) {
        EditText Name=(EditText) findViewById(R.id.EditTextName);
        EditText Quantity=(EditText) findViewById(R.id.EditTextQuantity);
        Intent in=getIntent();
        String Dname=in.getStringExtra("dish");
        String name=Name.getText().toString();
        String quantity=Quantity.getText().toString();
        String toastText="Hi "+name+"\n You have ordered for "+quantity+" "+Dname;
        Toast.makeText(getApplicationContext(),toastText,Toast.LENGTH_LONG).show();
    }
}
