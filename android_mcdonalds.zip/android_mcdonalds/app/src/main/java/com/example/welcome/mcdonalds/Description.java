package com.example.welcome.mcdonalds;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;

public class Description extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_description);


        Intent intent=getIntent();
        int position=intent.getIntExtra("position",0);

        android.support.v4.app.FragmentManager fragmentManager = getSupportFragmentManager();
        android.support.v4.app.FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();

        if(position==0)
        {
            Triple hello = new Triple();
            fragmentTransaction.add(R.id.fragment_container, hello, "HELLO");
            fragmentTransaction.commit();
        }
        else if(position==1)
        {
            Bigmac hello = new Bigmac();
            fragmentTransaction.add(R.id.fragment_container, hello, "HELLO");
            fragmentTransaction.commit();
        }
        else if(position==2)
        {
            fiet hello = new fiet();
            fragmentTransaction.add(R.id.fragment_container, hello, "HELLO");
            fragmentTransaction.commit();
        }
        else if(position==3)
        {
            Ham hello = new Ham();
            fragmentTransaction.add(R.id.fragment_container, hello, "HELLO");
            fragmentTransaction.commit();
        }
        else if(position==4)
        {
            Double hello = new Double();
            fragmentTransaction.add(R.id.fragment_container, hello, "HELLO");
            fragmentTransaction.commit();
        }
        else
        {
            Quarter hello = new Quarter();
            fragmentTransaction.add(R.id.fragment_container, hello, "HELLO");
            fragmentTransaction.commit();
        }

    }
    public void bookOrder(View view) {
        Intent intent=getIntent();
        int position=intent.getIntExtra("position",0);
        String dishname;
        if(position==0)
        {
            dishname="Big Mac";
        }
        else if(position==1)
        {
            dishname="Filet-O-Fish";
        }
        else if(position==2)
        {
            dishname="Hamburger";
        }
        else if(position==3)
        {
            dishname="Double Cheeseburger";
        }
        else if(position==4)
        {
            dishname="Quarter Pounder with Cheese";
        }
        else
        {
            dishname="Double Big Mac";
        }

        Intent in = new Intent(getApplicationContext(), com.example.welcome.mcdonalds.Book.class);
        in.putExtra("dish",dishname);
        startActivity(in);
    }
}
