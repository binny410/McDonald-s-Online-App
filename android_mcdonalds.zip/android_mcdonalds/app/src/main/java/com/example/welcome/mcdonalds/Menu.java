package com.example.welcome.mcdonalds;

import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Menu extends AppCompatActivity {

    String menu[] = {"Big Mac", "Filet-O-Fish", "Hamburger","Double Cheeseburger","Quarter Pounder with Cheese","Double Big Mac"};

    String num[]={"$10","$60","$70","$90","$20","$40"};
    int flags[]={R.drawable.big_mac,R.drawable.fiet,R.drawable.ham,R.drawable.double_,R.drawable.quarter,R.drawable.triple};
    SimpleAdapter adapter;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        ListView myList=(ListView) findViewById(R.id.myMenuList);
        List<HashMap<String,String>> aList = new ArrayList<HashMap<String,String>>();

        for(int i=0;i<6;i++){
            HashMap<String, String> hm = new HashMap<String,String>();
            hm.put("txt",menu[i]);
            hm.put("flag", Integer.toString(flags[i]) );
            hm.put("num",num[i]);
            aList.add(hm);
        }
        String[] from = { "flag","txt","num" };

        // Ids of views in listview_layout
        int[] to = { R.id.flag,R.id.txt,R.id.num};
        adapter = new SimpleAdapter(getApplicationContext(), aList, R.layout.listview, from,to);
        myList.setAdapter(adapter);

        myList.setOnItemClickListener(new AdapterView.OnItemClickListener()
        {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                int position=i;
               Intent in=new Intent(getApplicationContext(),Description.class);
               in.putExtra("position",position);
               startActivity(in);
            }
        });
    }
}
